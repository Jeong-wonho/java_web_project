package com.day.exception;

public class FindException extends Exception {

	public FindException(String message) {
		super(message);
		
	}
	
}
