package com.day.exception;

public class RemoveException extends Exception {

	public RemoveException(String message) {
		super(message);
		
	}
	
}
