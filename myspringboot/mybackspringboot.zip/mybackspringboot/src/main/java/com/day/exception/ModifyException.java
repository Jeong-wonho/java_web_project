package com.day.exception;

public class ModifyException extends Exception {

	public ModifyException(String message) {
		super(message);
		
	}

}
